package atl.acadamey.studentclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
